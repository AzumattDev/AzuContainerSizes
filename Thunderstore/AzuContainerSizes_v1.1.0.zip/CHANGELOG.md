| `Version` | `Update Notes`                                                           |
|-----------|--------------------------------------------------------------------------|
| 1.1.0     | - Update for Bog Witch                                                   |
| 1.0.3     | - Update for Valheim's latest update (0.217.46)                          |
| 1.0.2     | - Update for Valheim's latest update                                     |
| 1.0.1     | - Had to fix a readme error. 1.0.1 is only the version for thunderstore. |
| 1.0.0     | - Initial Release                                                        |